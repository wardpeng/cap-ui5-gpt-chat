import BaseController from "./BaseController";

/**
 * @namespace com.p36.capui5gptchat.controller
 */
export default class NoChat extends BaseController {}
